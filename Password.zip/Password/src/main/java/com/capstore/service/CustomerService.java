package com.capstore.service;

import com.capstore.bean.*;

public interface CustomerService {

	// Customer updatePassword(String newpassword,Customer c);

	Iterable<Customer> getAll();

	// String updatePassword(String custEmail, String newpassword);

	String changePassword(int id, String email, String password);

}
