package com.capstore.service;

import com.capstore.bean.*;

public interface CustomerService {

	String addPassword(String custEmail, String newpassword);

	// Customer updatePassword(String newpassword,Customer c);

	Iterable<Customer> getAll();

	String updatePassword(String custEmail, String newpassword);

	Customer getEmail(int id);

	Customer getPassword(int id);

}
