import { Component, OnInit } from '@angular/core';
import { UserModel } from '../models/User';
import { Input, Output, EventEmitter } from '@angular/core';



@Component({
  selector: 'app-changepassword',
  templateUrl: './changepassword.component.html',
  styleUrls: ['./changepassword.component.css']
})
export class ChangepasswordComponent implements OnInit {

  @Input() user: UserModel
  @Input() isEditing: boolean;
  incorrectPasswordStatus = false;
  userArr: UserModel[] = [];
  constructor() {
  this.user = new UserModel();
  }

  ngOnInit() {
    
  }
  
  validate() {

    if (this.user.newPassword == this.user.confirmPassword) {
      alert("Password Changed Scuccessfully");
    }

  }
  validateboth() {
    if (this.user.currentPassword == this.user.newPassword) {
      this.incorrectPasswordStatus = true;
      this.user.newPassword = "";

    }

  }
  cancel() {
    this.user.currentPassword = "";
    this.user.confirmPassword = "";
    this.user.newPassword = "";
  }
}
