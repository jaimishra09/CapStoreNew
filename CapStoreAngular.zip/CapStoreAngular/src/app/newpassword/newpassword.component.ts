import { Component, OnInit } from '@angular/core';
import { UserModel } from '../models/User';
import { Input, Output, EventEmitter } from '@angular/core';
@Component({
  selector: 'app-newpassword',
  templateUrl: './newpassword.component.html',
  styleUrls: ['./newpassword.component.css']
})
export class NewpasswordComponent implements OnInit {

  @Input() user: UserModel
  @Input() isEditing: boolean;
  

  constructor() {
    this.user = new UserModel();
  }


  ngOnInit() {
  }
  validate() {

    if (this.user.newPassword == this.user.confirmPassword) {
      alert("Password Changed Scuccessfully");
    }
    else {
      alert("Password Does not match");
      this.user.newPassword="";
      this.user.confirmPassword="";
    }

  }
  cancel(){
    this.user.newPassword="";
    this.user.confirmPassword="";
  }

}

