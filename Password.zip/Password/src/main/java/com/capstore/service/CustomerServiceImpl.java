package com.capstore.service;

import java.util.NoSuchElementException;

import javax.persistence.EntityManager;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
import com.capstore.repo.*;
import com.capstore.bean.Customer;

@Repository
public class CustomerServiceImpl implements CustomerService {
	private EntityManager em;
	@Autowired
	CustomerRepo repo;

	@Override
	public String updatePassword(String email, String password) {
		Customer customer = new Customer();
		customer.setEmail(email);
		customer.setPassword(password);
		return "password updated";
	}

	@Transactional
	public Iterable<Customer> getAll() {// Retrieve all employees from database
		return repo.findAll();
	}

	@Override
	public String addPassword(String email, String password) {
		Customer customer = new Customer();
		customer.setEmail(email);
		customer.setPassword(password);
		return "password changed";
	}

	@Override
	public Customer getEmail(int id) {
		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Customer found for this id :" + id);
		}
	}

	@Override
	public Customer getPassword(int id) {
		try {
			return repo.findById(id).get();
		} catch (NoSuchElementException e) {
			throw new NoSuchElementException("No Customer found for this id :" + id);
		}
	}
}
