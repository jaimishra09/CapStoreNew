import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ChangepasswordComponent } from './changepassword/changepassword.component';
import { NewpasswordComponent } from './newpassword/newpassword.component';

const routes: Routes = [
  { path: '', redirectTo: '', pathMatch: 'full' },
  {path: 'changepassword', component: ChangepasswordComponent},
  {path: 'newpassword', component: NewpasswordComponent}


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
