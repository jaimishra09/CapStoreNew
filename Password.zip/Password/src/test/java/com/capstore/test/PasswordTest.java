package com.capstore.test;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.capstore.service.CustomerServiceImpl;

public class PasswordTest {

	CustomerServiceImpl service = null;

	@Before
	public void setUp() {
		service = new CustomerServiceImpl();
	}

	@After
	public void tearDown() {
		service = null;
	}
	
	@Test
	public void changePassword() {
		try {
			String s = service.changePassword(101,"ankush@gmail.com","ankush123");
			Assert.assertNotNull(s);
		} catch (Exception e) {
			System.out.println(e);
		}
	}
}
