package com.capstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.capstore.bean.Customer;
import com.capstore.repo.CustomerRepo;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	CustomerRepo repo;
	Customer customer;

	@Override
	public String changePassword(int id, String email, String password) {

		customer = new Customer();
		customer = repo.findById(id).get();
		if (customer.getPassword().equals(password)) {
			return "password should not match with previous password";
		} 
		else if(!(customer.getEmail().equals(email))) {
			return "Email is incorrect";
		}
		else {
			customer.setPassword(password);
			repo.save(customer);
			return "password updated";
		}
	}

	@Transactional
	public Iterable<Customer> getAll() {// Retrieve all employees from database
		return repo.findAll();
	}

}
